CREATE TABLE Employee 
( EmployeeID INT IDENTITY(100,1) PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50),
	Date_of_Birth Date,
	DepartmentID INT NOT NULL,
	Annual_Salary INT
);

CREATE TABLE Department
( DepartmentID INT  IDENTITY PRIMARY KEY,
Department_Name VARCHAR(50),
Location VARCHAR(50)
);