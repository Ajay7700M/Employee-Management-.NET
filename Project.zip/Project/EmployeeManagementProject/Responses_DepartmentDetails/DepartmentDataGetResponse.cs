﻿using EmployeeManagementProject.Model;
using EmployeeManagementProject.Model_Department;
using EmployeeManagementProject.Model_Employee;

namespace EmployeeManagementProject.Responses_DepartmentDetails
{
    public class DepartmentDataGetResponse
    {
        public DepartmentDetailsGET[] employees { get; set; }
        public int StatusCode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
