﻿using EmployeeManagementProject.Model_Department;
using EmployeeManagementProject.Model_Employee;

namespace EmployeeManagementProject.Responses_DepartmentDetails
{
    public class DepartmentDetailsGETIDResponse
    {
        public DepartmentDetailsGET employee { get; set; }
        public int StatusCode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
