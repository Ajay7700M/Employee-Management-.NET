﻿namespace EmployeeManagementProject.Responses_DepartmentDetails
{
    public class DepartmentDetailsPOSTResponsecs
    {
        public int errorCode { get; set; }
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
    }
}
