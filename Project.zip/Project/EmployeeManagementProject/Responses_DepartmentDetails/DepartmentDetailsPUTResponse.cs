﻿using EmployeeManagementProject.Model;
using EmployeeManagementProject.Model_Employee;

namespace EmployeeManagementProject.Responses_DepartmentDetails
{
    public class DepartmentDetailsPUTResponse
    {
        public EmployeeDetailsGET employee { get; set; }
        public int errorCode { get; set; }
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
    }
}
