﻿namespace EmployeeManagementProject.Responses_DepartmentDetails
{
    public class DepartmentDetailsDELETEResponse
    {
        public string SuccessMessage { get; set; }
        public bool IsSuccess { get; set; }
        public int errorCode { get; set; }
        public string ErrorMessage { get; set; }
    }
}
