﻿namespace EmployeeManagementProject.Model_Department
{
    public class DepartmentDetailsGET
    {
        public int DepartmentID { get; set; }
        public string Department_Name { get; set; }
        public string Location { get; set; }
    }
}
