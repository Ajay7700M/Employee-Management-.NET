﻿using Microsoft.VisualBasic;

namespace EmployeeManagementProject.Model_Employee
{
    public class EmployeeDetailsGET
    {
       
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DOB { get; set; }
        public int DepartmentID { get; set; }
        public int  Salary { get; set; }
        public int EmployeeID { get; set; }
    }
}
