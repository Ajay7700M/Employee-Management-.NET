﻿using Azure.Core;
using EmployeeManagementProject.Model;
using EmployeeManagementProject.Model_Employee;
using EmployeeManagementProject.Responses_EmployeeDetails;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Web;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeManagementProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        public EmployeeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        // GET: api/<EmployeeController>
        [HttpGet]
        [Route("GetEmployees")]
        public GetResponse GetEmployees()
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString());
            SqlDataAdapter da = new SqlDataAdapter(@"SELECT E.First_Name, E.Last_Name, D.Department_Name, E.EmployeeID,E.Date_of_Birth,E.Annual_Salary
                                                   FROM Employee E 
                                                   INNER JOIN Department D ON E.DepartmentID = D.DepartmentID", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<Employee> employeeList = new List<Employee>();
            GetResponse response = new GetResponse();
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Employee employee = new Employee();
                    employee.First_Name = (string)dt.Rows[i]["First_Name"];
                    employee.Last_Name = (string)dt.Rows[i]["Last_Name"];
                    employee.EmployeeID = Convert.ToInt32(dt.Rows[i]["EmployeeID"]);
                    employee.DepartmentName = (string)dt.Rows[i]["Department_Name"];
                    employee.Dob = dt.Rows[i]["Date_of_Birth"].ToString();
                    employee.Salary = Convert.ToInt32(dt.Rows[i]["Annual_Salary"]);
                    employeeList.Add(employee);
                }
            }
            if (employeeList.Count > 0)
            {
                response.employees = employeeList.ToArray();
                response.StatusCode = 200;
            }
            else
            {
                response.ErrorMessage = "No Data Found";
                response.StatusCode = 100;
            }
            return response;
        }

        // GET api/<EmployeeController>/5
        [HttpGet("{EmployeeID}")]
        public GetParticularIdResponse Get(int EmployeeID)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString());
            SqlDataAdapter da = new SqlDataAdapter(@$"SELECT E.First_Name, E.Last_Name, D.Department_Name, E.EmployeeID,E.Annual_Salary,D.DepartmentID,E.Date_of_Birth
                                                   FROM Employee E 
                                                   INNER JOIN Department D ON E.DepartmentID = D.DepartmentID
                                                   WHERE E.EmployeeID = {EmployeeID}", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GetParticularIdResponse response = new GetParticularIdResponse();
            if (dt.Rows.Count == 1)
            {
                Employee employee = new Employee();
                employee.First_Name = dt.Rows[0]["First_Name"].ToString();
                employee.Last_Name = dt.Rows[0]["Last_Name"].ToString();
                employee.EmployeeID = Convert.ToInt32(dt.Rows[0]["EmployeeID"]);
                employee.DepartmentName = dt.Rows[0]["Department_Name"].ToString();
                employee.Salary = Convert.ToInt32(dt.Rows[0]["Annual_Salary"]);
                employee.DepartmentID = Convert.ToInt32(dt.Rows[0]["DepartmentID"]);
                employee.Dob=dt.Rows[0]["Date_of_Birth"].ToString();
                response.employee = employee;

                response.StatusCode = 200;
            }
            else
            {
                response.ErrorMessage = "No Data Found";
                response.StatusCode = 100;
            }
            return response;
        }

        // POST api/<EmployeeController>
        [HttpPost]
        [Route("CreateEmployee")]
        public EmployeeDetailsPOSTResponsecs CreateEmployee(EmployeeDetailsGET request)
        {
            var result = new EmployeeDetailsPOSTResponsecs();

            string cmdString = "INSERT INTO Employee (First_Name, Last_Name, Date_of_Birth, DepartmentID, Annual_Salary) VALUES(@val1, @val2, @val3, @val4, @val5);";

            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString()))
            {
                using (SqlCommand comm = new SqlCommand())
                {
                    comm.Connection = conn;
                    comm.CommandText = cmdString;
                    comm.Parameters.AddWithValue("@val1", request.FirstName);
                    comm.Parameters.AddWithValue("@val2", request.LastName);
                    comm.Parameters.AddWithValue("@val3", request.DOB);
                    comm.Parameters.AddWithValue("@val4", request.DepartmentID);
                    comm.Parameters.AddWithValue("@val5", request.Salary);
                    


                    try
                    {
                        conn.Open();
                        comm.ExecuteNonQuery();

                        result.SuccessMessage = "New Data Added Successfully.";
                    }
                    catch (Exception ex)
                    {
                        result.errorCode = 200;
                        result.ErrorMessage = ex.Message;
                    }
                }
            }
            return result;
        }

        // PUT api/<EmployeeController>/5
        [HttpPut("UpdateDetails")]
        public EmployeeDetailsPUTResponse Put(EmployeeDetailsGET request)
        {
            var result = new EmployeeDetailsPUTResponse();
            string cmdString = @$"UPDATE Employee 
                                  SET First_Name = '{request.FirstName}',
                                      Last_Name = '{request.LastName}',
                                      DepartmentID='{request.DepartmentID}',
                                      Date_of_Birth = '{request.DOB}',
                                      Annual_Salary = '{request.Salary}'
                                  WHERE EmployeeID = {request.EmployeeID} ;";

            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString()))
            {
                using (SqlCommand comm = new SqlCommand())
                {
                    comm.Connection = conn;
                    comm.CommandText = cmdString;

                    try
                    {
                        conn.Open();
                        comm.ExecuteNonQuery();

                        result.SuccessMessage = "New Data Updated Successfully.";
                    }
                    catch (Exception ex)
                    {
                        result.errorCode = 200;
                        result.ErrorMessage = ex.Message;
                    }
                }
            }
            return result;
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{EmployeeID}")]
        public EmployeeDetailsDELETEResponse Delete(int EmployeeID)
        {

            string Cmdstring = @$"DELETE FROM Employee
                                  WHERE EmployeeID = {EmployeeID};";

            var result = new EmployeeDetailsDELETEResponse();

            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString()))
            {
                using (SqlCommand comm = new SqlCommand())
                {
                    comm.Connection = conn;
                    comm.CommandText = Cmdstring;

                    try
                    {
                        conn.Open();
                        comm.ExecuteNonQuery();

                        result.SuccessMessage = "Data Deleted Successfully.";
                    }
                    catch (Exception ex)
                    {
                        result.errorCode = 200;
                        result.ErrorMessage = ex.Message;
                    }
                }
            }
            return result;
        }
    }
}
