﻿using EmployeeManagementProject.Model_Department;
using EmployeeManagementProject.Model_Employee;
using EmployeeManagementProject.Responses_DepartmentDetails;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeManagementProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentDataController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        public DepartmentDataController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET: api/<EmployeeDataController>
        [HttpGet]
        [Route("GetEmployees")]
        public DepartmentDataGetResponse GetEmployees()
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString());
            SqlDataAdapter da = new SqlDataAdapter(@"SELECT * FROM Department", con);
            
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            List<DepartmentDetailsGET> employeeList = new List<DepartmentDetailsGET>();
            DepartmentDataGetResponse response = new DepartmentDataGetResponse();
            
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DepartmentDetailsGET employee = new DepartmentDetailsGET();
                    employee.DepartmentID = Convert.ToInt32(dt.Rows[i]["DepartmentID"]);
                    employee.Department_Name = (string)dt.Rows[i]["Department_Name"];
                    employee.Location = (string)dt.Rows[i]["Location"];
                    employeeList.Add(employee);
                }
            }
            if (employeeList.Count > 0)
            {
                response.employees = employeeList.ToArray();
                response.StatusCode = 200;
            }
            else
            {
                response.ErrorMessage = "No Data Found";
                response.StatusCode = 100;
            }
            return response;
        }

        // GET api/<EmployeeDataController>/5
        [HttpGet("{DepartmentID}")]
        public DepartmentDetailsGETIDResponse Get(int DepartmentID)
        {

            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString());
            SqlDataAdapter da = new SqlDataAdapter(@$"SELECT * FROM Department WHERE DepartmentID = {DepartmentID}", con);

            DataTable dt = new DataTable();
            da.Fill(dt);
            DepartmentDetailsGETIDResponse response = new DepartmentDetailsGETIDResponse();

            if (dt.Rows.Count == 1)
            {
                DepartmentDetailsGET employee = new DepartmentDetailsGET();
                employee.DepartmentID = Convert.ToInt32(dt.Rows[0]["DepartmentID"]);
                employee.Department_Name = (string)dt.Rows[0]["Department_Name"];
                employee.Location = (string)dt.Rows[0]["Location"];

                response.employee = employee;
                response.StatusCode = 200;
            }
            else
            {
                response.ErrorMessage = "No Data Found";
                response.StatusCode = 100;
            }
            return response;
        }



        // POST api/<EmployeeDataController>
        [HttpPost]
        [Route("CreateEmployee")]
        public DepartmentDetailsPOSTResponsecs CreateEmployee(DepartmentDetailsGET request)
        {
            var result = new DepartmentDetailsPOSTResponsecs();

            string cmdString = "INSERT INTO Department (Department_Name, Location) VALUES(@val1, @val2);";

            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString()))
            {
                using (SqlCommand comm = new SqlCommand())
                {
                    comm.Connection = conn;
                    comm.CommandText = cmdString;
                    comm.Parameters.AddWithValue("@val1", request.Department_Name);
                    comm.Parameters.AddWithValue("@val2", request.Location);



                    try
                    {
                        conn.Open();
                        comm.ExecuteNonQuery();

                        result.SuccessMessage = "New Data Added Successfully.";
                    }
                    catch (Exception ex)
                    {
                        result.errorCode = 200;
                        result.ErrorMessage = ex.Message;
                    }
                }
            }
            return result;
        }

        // PUT api/<EmployeeDataController>/5
        [HttpPut("UpdateDetails")]
        public DepartmentDetailsPUTResponse Put(DepartmentDetailsGET request)
        {
            var result = new DepartmentDetailsPUTResponse();
            string cmdString = @$"UPDATE Department 
                                  SET Department_Name = '{request.Department_Name}',
                                      Location = '{request.Location}'
                                  WHERE DepartmentID = {request.DepartmentID} ;";

            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString()))
            {
                using (SqlCommand comm = new SqlCommand())
                {
                    comm.Connection = conn;
                    comm.CommandText = cmdString;

                    try
                    {
                        conn.Open();
                        comm.ExecuteNonQuery();

                        result.SuccessMessage = "New Data Updated Successfully.";
                    }
                    catch (Exception ex)
                    {
                        result.errorCode = 200;
                        result.ErrorMessage = ex.Message;
                    }
                }
            }
            return result;
        }

        // DELETE api/<EmployeeDataController>/5
        [HttpDelete("{DepartmentID}")]

        public DepartmentDetailsDELETEResponse Delete(int DepartmentID)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString());
            SqlDataAdapter da = new SqlDataAdapter(@$"SELECT * FROM Employee WHERE DepartmentID = {DepartmentID}", con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            string Cmdstring = @$"DELETE FROM Department
                                  WHERE DepartmentID = {DepartmentID};";

            var result = new DepartmentDetailsDELETEResponse();

            using (SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString()))
            {
                using (SqlCommand comm = new SqlCommand())
                {
                    comm.Connection = conn;
                    comm.CommandText = Cmdstring;

                    try
                    {
                        if(dt.Rows.Count > 0)
                        {
                            result.errorCode = 200;
                            result.ErrorMessage = "There is more than one employee in the department. So, change those employees to another department and then try to delete it. ";
                            result.IsSuccess = false;
                        }
                        else
                        {
                            conn.Open();
                            comm.ExecuteNonQuery();

                            result.SuccessMessage = "Data Deleted Successfully.";
                            result.IsSuccess = true;
                        }                        
                    }
                    catch (Exception ex)
                    {
                        result.errorCode = 200;
                        result.ErrorMessage = ex.Message;
                    }
                }
            }
            return result;
        }


    }
}
