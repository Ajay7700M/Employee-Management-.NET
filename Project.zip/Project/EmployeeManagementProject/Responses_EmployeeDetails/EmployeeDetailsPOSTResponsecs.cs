﻿namespace EmployeeManagementProject.Responses_EmployeeDetails
{
    public class EmployeeDetailsPOSTResponsecs
    {
        public int errorCode { get; set; }
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
    }
}
