﻿using EmployeeManagementProject.Model;

namespace EmployeeManagementProject.Responses_EmployeeDetails
{
    public class GetParticularIdResponse
    {
        public Employee employee { get; set; }
        public int StatusCode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
