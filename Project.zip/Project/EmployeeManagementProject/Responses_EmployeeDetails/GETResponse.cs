﻿using EmployeeManagementProject.Model;

namespace EmployeeManagementProject.Responses_EmployeeDetails
{
    public class GetResponse
    {
        public Employee[] employees { get; set; }
        public int StatusCode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
