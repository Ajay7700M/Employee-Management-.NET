﻿using EmployeeManagementProject.Model;
using EmployeeManagementProject.Model_Employee;

namespace EmployeeManagementProject.Responses_EmployeeDetails
{
    public class EmployeeDetailsPUTResponse
    {
        public int errorCode { get; set; }
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
    }
}
