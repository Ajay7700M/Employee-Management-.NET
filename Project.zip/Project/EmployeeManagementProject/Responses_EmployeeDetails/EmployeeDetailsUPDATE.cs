﻿namespace EmployeeManagementProject.Responses_EmployeeDetails
{
    public class EmployeeDetailsUPDATE
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int EmployeeID { get; set; }
        public string DepartmentName { get; set; }
        public string Location { get; set; }
        public string DOB { get; set; }
        public int Salary { get; set; }
    }
}
