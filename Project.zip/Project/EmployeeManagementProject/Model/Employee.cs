﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeManagementProject.Model
{
    public class Employee
    {
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public int EmployeeID { get; set; }
        public string DepartmentName { get; set; }
        public string Dob { get; set; }
        public int Salary { get; set; }

        public int DepartmentID { get; set; }

    }
}
