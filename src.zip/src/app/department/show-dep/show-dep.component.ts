import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { DepartmentData } from 'src/app/models/department/departmentdata.model';
import { SharedService } from 'src/app/shared.service';
import { AddEditDepComponent } from '../add-edit-dep/add-edit-dep.component';
@Component({
  selector: 'app-show-dep',
  templateUrl: './show-dep.component.html',
  styleUrls: ['./show-dep.component.css']
})
export class ShowDepComponent implements OnInit{
showSuccess: boolean = false;
  constructor (private service:SharedService,
    private route: Router,
    private dialog: MatDialog){}

  DepartmentList:DepartmentData[];

  ngOnInit(): void {
    this.refreshDepList();
  }
  refreshDepList()
  {
    this.service.getDepList().subscribe(data=>
      {
        this.DepartmentList = data.employees;        
      });
  }

  onAddClicked(data: any){
    this.service.setCurrenDepartmentId(data.departmentID);
    this.route.navigate(['addeditdep']);
  }

  deletefunction(data: DepartmentData){
    if(confirm("Are you sure you want to delete this data?")){
      this.service.deleteDepList(data.departmentID).subscribe((data:any)=>{
        console.log(data);
        if(data.isSuccess){
          this.showSuccess = true;
        }
        else{
          throwError ( ()=> new Error());          
        }
      });
    }
  }
  getnewdepdata()
  {
    this.service.setCurrenDepartmentId('0');
    this.route.navigate(['addeditdep']);
  }
}
