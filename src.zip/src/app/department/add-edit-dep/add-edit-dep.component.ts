import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { MatDialogRef } from '@angular/material/dialog';
import { SharedService } from 'src/app/shared.service';
import { DepartmentData } from 'src/app/request/department/getdepartmentrequest.model';
@Component({
  selector: 'app-add-edit-dep',
  templateUrl: './add-edit-dep.component.html',
  styleUrls: ['./add-edit-dep.component.css']
})
export class AddEditDepComponent implements OnInit {
  particularDepartment:DepartmentData;
  currentDepartmentId: string | null = "";
  constructor(private route:Router
    , private service:SharedService){}


  ngOnInit(): void {
    this.service.getCurrentDepartmentId().subscribe(
      {
        next:(data) =>{
          this.currentDepartmentId = data;
          console.log(data);
          if(data != '0'){
            this.service.getParticularDepartment(data).subscribe(
              {
                next:(result)=>{
                  this.particularDepartment = result.employee;
                  console.log(this.particularDepartment);
                }
              }
            )
          }
          else{
            console.log("Entered");
            let emptyDepData = new DepartmentData();
            emptyDepData.departmentID = 0;
            emptyDepData.department_Name = "";
            emptyDepData.location = "";
            this.particularDepartment = emptyDepData;

            console.log(this.particularDepartment);
          }
        }
      }
    )
  }
  onCloseClicked(){
    this.route.navigate(['department']);
   }

 UpdateSubmit(){
  if(this.particularDepartment.departmentID == 0){
    this.service.postDepList(this.particularDepartment).subscribe((response:any)=>{
      console.log(response);
      this.route.navigate(['department']);
    });
  }
  else{
    this.service.updateDepList(this.particularDepartment).subscribe((response:any)=>{
      console.log(response);
      this.route.navigate(['department']);
    });

  }
 }
}
