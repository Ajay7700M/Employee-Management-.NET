export class PostDepartmentRequest{
    constructor(init?: Partial<PostDepartmentRequest>){
        Object.assign(this,init);
    }

    public departmentID:number;
    public department_Name:string;
    public location:string;
}

export class PostDepartmentResponse{
    constructor(data : any)
    {
        Object.assign(this,data);
    }
    public successMessage: string;
    public statusCode: number;
    public errorMessage:string;
}