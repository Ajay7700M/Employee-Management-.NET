export class DepartmentData{
    constructor(init?: Partial<DepartmentData>){
        Object.assign(this,init);
    }

    public departmentID:number;
    public department_Name:string;
    public location:string;
}

export class GetDepartmentResponse {
    constructor(data : any)
    {
        Object.assign(this,data);
    }
    public employees: DepartmentData[];
    public statusCode: number;
    public errorMessage:string;
}