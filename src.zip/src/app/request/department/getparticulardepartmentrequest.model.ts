import { DepartmentData } from "./getdepartmentrequest.model";

export class GetParticularDepartmentResponse{
    constructor(data : any)
    {
        Object.assign(this,data);
    }
    public employee: DepartmentData;
    public statusCode: number;
    public errorMessage:string;
}