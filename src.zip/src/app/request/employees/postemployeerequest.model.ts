export class PostEmployeeRequest{
    constructor(data:any){
        Object.assign(this,data);
    }
    public firstName:string;
    public lastName:string;
    public employeeID:number;
    public dob:string;
    public departmentID:number;
    public salary:number;
}

export class PostEmployeeResponse{
    constructor(data:any){
        Object.assign(this,data);
    }
    public errorCode:number;
    public successMessage:string;
    public errorMessage:string;
}