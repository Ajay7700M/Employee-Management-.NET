import { EmployeeData } from "src/app/models/employee/employeedata.model";

export class GetEmployeeResponse{
    constructor(data:any){
        Object.assign(this,data);
    }

    public employee:EmployeeData;
    public statusCode:number;
    public errorMessage:string;
}