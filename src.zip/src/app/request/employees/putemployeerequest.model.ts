
export class PutEmployeeData{
    constructor (init?: Partial<PutEmployeeData>)
    {
        Object.assign(this,init);
    }

    public salary:number;
    public departmentName:string;
    public departmentID:number;
    public firstName:string;
    public lastName:string;
    public dob:string;
    public employeeID:number;
}


export class PutEmployeeResponse{
    constructor(data:any){
        Object.assign(this,data);
    }
    public employees: PutEmployeeData[];
    public statusCode:number;
    public errorMessage:string;
    public successMessage:string;
}

