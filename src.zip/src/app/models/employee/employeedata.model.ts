export class EmployeeData{   

    constructor(init?: Partial<EmployeeData>){
        Object.assign(this, init);
    }

    public first_Name: string;
    public last_Name: string;
    public employeeID: number;
    public dob: string;
    public salary:number;
    public departmentID: number;
    public departmentName:string;        //the names are to be given as per the names on swagger api call
}
