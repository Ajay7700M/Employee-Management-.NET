export class PostEmployeeData{
    constructor(init?: Partial<PostEmployeeData>){
        Object.assign(this,init);
    }

    public firstName:string;
    public lastName:string;
    public dob:Date;
    public departmentID:number;
    public salary:number;
    public employeeID:number;
}