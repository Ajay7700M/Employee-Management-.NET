
export class PutEmployeeData{
    constructor (init?: Partial<PutEmployeeData>)
    {
        Object.assign(this,init);
    }

    public salary:number;
    public departmentName:string;
    public departmentID:number;
}