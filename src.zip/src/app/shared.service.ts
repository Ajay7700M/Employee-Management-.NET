import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, VirtualTimeScheduler } from 'rxjs';
import { GetDepartmentResponse } from './request/department/getdepartmentrequest.model';
import { PutEmployeeData } from './models/employee/putemployeedata.model';
import { PutEmployeeResponse } from './request/employees/putemployeerequest.model';
import { PostEmployeeData } from './models/employee/postemployeedata.model';
import { PostEmployeeRequest, PostEmployeeResponse } from './request/employees/postemployeerequest.model';
import { EmployeeData } from './models/employee/employeedata.model';
import { GetEmployeeResponse } from './request/employees/getemployeerequest.model';
import { DepartmentData } from './models/department/departmentdata.model';
import { GetParticularDepartmentResponse } from './request/department/getparticulardepartmentrequest.model';
import { PostDepartmentRequest, PostDepartmentResponse } from './request/department/postdepartmentrequest.model';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
};

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  private EmployeeID: string = "SELECTED_EMPLOYEE_ID";
  private currentEmployeeId$: BehaviorSubject<string|null> = new BehaviorSubject<string|null>(localStorage.getItem(this.EmployeeID));
  private DepartmentID: string = "SELECTED_DEPARTMENT_ID";
  private currentDepartmentId$: BehaviorSubject<string|null> = new BehaviorSubject<string|null>(localStorage.getItem(this.DepartmentID));

  readonly APIUrl= "https://localhost:7097/api";
  constructor(private http:HttpClient) { }
/*********************Employee********************* */
  setCurrenEmployeeId(EmployeeId:string):void{
    localStorage.setItem(this.EmployeeID, EmployeeId);
    this.currentEmployeeId$.next(EmployeeId);
  }

  getCurrentEmployeeId(): Observable<string | null>{
    return this.currentEmployeeId$;
  }

  getParticularEmployee(EmployeeID:any):Observable<GetEmployeeResponse> {
    return this.http.get<GetEmployeeResponse>(this.APIUrl + '/Employee/'+`${EmployeeID}`);
  }

/**********************Department******************** */
  setCurrenDepartmentId(DepartmentId:string):void{
    localStorage.setItem(this.DepartmentID, DepartmentId);
    this.currentDepartmentId$.next(DepartmentId);
  }

  getCurrentDepartmentId(): Observable<string | null>{
    return this.currentDepartmentId$;
  }

  getParticularDepartment(DepartmentID:any):Observable<GetParticularDepartmentResponse> {
    return this.http.get<GetParticularDepartmentResponse>(this.APIUrl + '/DepartmentData/'+`${DepartmentID}`);
  }
/****************Department API************************ */
  getDepList():Observable<GetDepartmentResponse>{
    return this.http.get<GetDepartmentResponse>(this.APIUrl+'/DepartmentData/GetEmployees');
  }

 
  //to add values to the department(POST)
  postDepList(value : DepartmentData) : Observable<PostDepartmentResponse>
  {
    let request : PostDepartmentRequest = {
      departmentID:value.departmentID,
      location:value.location,
      department_Name:value.department_Name,
    }
    return this.http.post<PostDepartmentResponse>(this.APIUrl+'/DepartmentData/CreateEmployee',request,httpOptions);
  }
  
  //to update a departmrnt value in table (PUT)
  updateDepList(value:DepartmentData): Observable<PostDepartmentResponse>
  {
    let request : PostDepartmentRequest = {
      departmentID:value.departmentID,
      location:value.location,
      department_Name:value.department_Name,
    }
    return this.http.put<PostDepartmentResponse>(this.APIUrl+'/DepartmentData/UpdateDetails',request,httpOptions)
  }

  //to delete an particular id in table (DELETE)
  deleteDepList(value:any)
  {
    return this.http.delete(this.APIUrl+'/DepartmentData/'+`${value}`);
  }

/***************************Employee API******************* */
    //to get employee(GET)
    getEmpList():Observable<any>
    {
      return this.http.get<any>(this.APIUrl+'/Employee/GetEmployees');
    }
    //to add values to the employee(POST)
    postEmpList(value:EmployeeData):Observable<PostEmployeeResponse>
    {
      let request : PostEmployeeRequest = {
        firstName:value.first_Name,
        lastName:value.last_Name,
        departmentID:value.departmentID,
        dob:value.dob,
        salary:value.salary,
        employeeID:value.employeeID
      }
      return this.http.post<PostEmployeeResponse>(this.APIUrl+'/Employee/CreateEmployee',request,httpOptions);
    }
    
    //to update a employee value in table (PUT)
    updateEmpList(value:EmployeeData):Observable<PutEmployeeResponse>
    {
      let request : PostEmployeeRequest = {
        firstName:value.first_Name,
        lastName:value.last_Name,
        departmentID:value.departmentID,
        dob:value.dob,
        salary:value.salary,
        employeeID:value.employeeID
      }
      return this.http.put<PutEmployeeResponse>(this.APIUrl+'/Employee/UpdateDetails/',request,httpOptions);
    }
  
    //to delete an particular id in table (DELETE)
    deleteEmpList(value:any)
    {
      return this.http.delete(this.APIUrl+'/Employee/'+`${value}`);
    }

  
}
  
