import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';
import { Route, Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { DepartmentData } from 'src/app/models/department/departmentdata.model';
import { EmployeeData } from 'src/app/models/employee/employeedata.model';
@Component({
  selector: 'app-add-new-emp',
  templateUrl: './add-new-emp.component.html',
  styleUrls: ['./add-new-emp.component.css']
})
export class AddNewEmpComponent implements OnInit {
  deplist:DepartmentData[];
  Newemployeedata: FormGroup;
  particularEmployee:EmployeeData;
  currentEmployeeId: string | null = "";
  Submit: boolean=true;
  EmployeeList: any;
  user: EmployeeData;
  constructor(private route:Router,
    private service:SharedService){}
    ngOnInit(): void {

      this.Newemployeedata = new FormGroup({
        fname: new FormControl('', [Validators.required]),
        lname: new FormControl('', [Validators.required]),
        dobf: new FormControl('', [Validators.required]),
        sal: new FormControl('', [Validators.required]),
        depname:new FormControl(0,[Validators.required])
      });

      this.service.getCurrentEmployeeId().subscribe(
        {
          next:(data) =>{
            this.currentEmployeeId = data;
            if(data !== '0'){
              this.service.getParticularEmployee(data).subscribe(
                {
                  next:(result)=>{
                    this.particularEmployee = result.employee;
                  }
                }
              )
            }
          }
        }
      )
      this.service.getDepList().subscribe((result)=>{
        this.deplist = result.employees;
      })
    }
  
   onCloseClicked(){
    this.route.navigate(['employees']);
   }
  //this is for post method
   getnewempdata(data: EmployeeData)
   {
    this.service.postEmpList(data).subscribe((result)=>{console.warn(result)});
   }

  addemployeedata() {
    let employee = new EmployeeData();
    employee.employeeID = 0;
    employee.departmentID = this.Newemployeedata.get("depname")?.value;
    employee.first_Name = this.Newemployeedata.get("fname")?.value;
    employee.last_Name = this.Newemployeedata.get("lname")?.value;
    employee.dob = this.Newemployeedata.get("dobf")?.value;
    employee.salary=this.Newemployeedata.get("sal")?.value;
    console.log(employee);

    if(employee.departmentID > 0){
      this.service.postEmpList(employee).subscribe((response: any) => {
        console.log(response);
      });
    }
    
}


  }
