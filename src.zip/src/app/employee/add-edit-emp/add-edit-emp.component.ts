import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { EmployeeData } from 'src/app/models/employee/employeedata.model';
import { DepartmentData } from 'src/app/request/department/getdepartmentrequest.model';
import { PutEmployeeData } from 'src/app/request/employees/putemployeerequest.model';
import { SharedService } from 'src/app/shared.service';
import { EmployeeComponent } from '../employee.component';

@Component({
  selector: 'app-add-edit-emp',
  templateUrl: './add-edit-emp.component.html',
  styleUrls: ['./add-edit-emp.component.css']
})
export class AddEditEmpComponent implements OnInit {
  deplist:DepartmentData[];
  particularEmployee:EmployeeData;
  currentEmployeeId: string | null = "";
  Submit: boolean=true;
  constructor(private route:Router,
    private service:SharedService){}

  ngOnInit(): void {
    this.service.getDepList().subscribe((result)=>{
      this.deplist = result.employees;
      console.log(this.deplist);
    });
    this.service.getCurrentEmployeeId().subscribe(
      {
        next:(data) =>{
          this.currentEmployeeId = data;
          if(data !== '0'){
            this.service.getParticularEmployee(data).subscribe(
              {
                next:(result)=>{
                  this.particularEmployee = result.employee;
                  console.log(this.particularEmployee);
                }
              }
            )
          }
        }
      }
    );
  }

 onCloseClicked(){
  this.route.navigate(['employees']);
 }
//this is put method
 UpdateSubmit(){
    this.service.updateEmpList(this.particularEmployee).subscribe((response: any) => {
      console.log(response);
    });
  }
  }
