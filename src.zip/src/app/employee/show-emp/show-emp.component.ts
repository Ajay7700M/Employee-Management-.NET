import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { SharedService } from 'src/app/shared.service';
import { AddEditEmpComponent } from '../add-edit-emp/add-edit-emp.component';
import { AddNewEmpComponent } from '../add-edit-emp/add-new-emp/add-new-emp.component';

@Component({
  selector: 'app-show-emp',
  templateUrl: './show-emp.component.html',
  styleUrls: ['./show-emp.component.css']
})
export class ShowEmpComponent implements OnInit{
  showSuccess: boolean = false;
  constructor (private service:SharedService,
    private route: Router,
    private dialog: MatDialog
    ){}

  EmployeeList:any;

  ngOnInit(): void {
    this.refreshEmpList();
  }
  refreshEmpList()
  {
    this.service.getEmpList().subscribe(data=>
      {
        this.EmployeeList=data
      });
  }

  onAddClicked(data: any){
    this.service.setCurrenEmployeeId(data.employeeID);
    this.route.navigate(['addeditemp']);
  }

  deletefunction(data: any){
    if(confirm("Are you sure you want to delete this data?")){
      this.service.deleteEmpList(data.employeeID ).subscribe((data:any)=>{
        console.log(data);
        if(data.isSuccess){
          this.showSuccess = true;
          this.ngOnInit();
        }
        else{
          throwError ( ()=> new Error());          
        }
      });
    }
  }
  getnewempdata()
  {
    this.service.setCurrenEmployeeId('0');
    this.route.navigate(['addnewemp']);
  }
 
}
