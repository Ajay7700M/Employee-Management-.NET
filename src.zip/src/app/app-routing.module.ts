import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentComponent } from './department/department.component';
import { AddEditEmpComponent } from './employee/add-edit-emp/add-edit-emp.component';
import { ShowDepComponent } from './department/show-dep/show-dep.component';
import { ShowEmpComponent } from './employee/show-emp/show-emp.component';
import { AddEditDepComponent } from './department/add-edit-dep/add-edit-dep.component';
import { AddNewEmpComponent } from './employee/add-edit-emp/add-new-emp/add-new-emp.component';
const routes: Routes = [
  {path:'employees',component:ShowEmpComponent},
  {path:'department',component:ShowDepComponent},
  {path:'addeditemp',component:AddEditEmpComponent},
  {path:'addeditdep',component:AddEditDepComponent},
  {path:'addnewemp',component:AddNewEmpComponent},  
  { path: '', pathMatch: 'full', redirectTo: '' },
  { path: '**', redirectTo: '' }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {anchorScrolling:'enabled'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
